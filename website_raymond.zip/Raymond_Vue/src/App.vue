<script>
import Products from "./components/Products.vue";
import Header from './components/Header.vue';

export default {
  components: {
    Products,
    Header,
  },
};
</script>

<template>
  <div style="color: #3366cc; font-size: 20px;  padding-top: 56px;">
    <h1>Top Locations</h1>
    <Rating initialRating='1' />
    <Rating initialRating='2' />
    <Rating initialRating='3' />
    <Rating initialRating='4' />
    <Rating initialRating='5' />
    <Products />
    <Header/>
  </div>
</template>