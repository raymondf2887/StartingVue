
<script>
</script>
<template>
  <nav class="navbar fixed-top" style="background-color: rgb(41, 123, 255);">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="https://d1nhio0ox7pgb.cloudfront.net/_img/i_collection_png/48x48/plain/graph_star.png" alt="Logo" width="30" height="30" class="d-inline-block align-text-top">
            Travel Locations
        </a>
        <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-dark bg-info-subtle" type="submit">Search</button>
        </form>
    </div>
  </nav>
</template>